package com.capgemini.jpa.presentation;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.utility.JPAUtil;

public class EmployeeTesterJPQL {

	public static void main(String[] args) 
	{
		EntityManager entityManager=JPAUtil.getEntityManager();
		/*String jpql1="select e from Employee e"; 
		TypedQuery<Employee> typedQuery=entityManager.createQuery(jpql1,Employee.class);
		List<Employee> empList=typedQuery.getResultList();
		showEmployees(empList);*/
		
		//show employee based on job condition
		
		String jpql1="select e from Employee e where e.job=:ptitle";
		TypedQuery<Employee> typedQuery=entityManager.createQuery(jpql1,Employee.class);
		typedQuery.setParameter("ptitle","Manager");
		Employee employee=typedQuery.getSingleResult();
		System.out.println(employee);

	}

	private static void showEmployees(List<Employee> empList) 
	{
		Iterator<Employee> iterator=empList.iterator();
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}
		
	}

}
